package com.vcreactions;

import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class VolumeSlider extends SliderWidget {
    public VolumeSlider(int x, int y, int width, int height) {
        super(x, y, width, height, Text.translatable("vcreactions.config.volume", VCReactionsClient.config.volume), VCReactionsClient.config.volume / 100.0);
    }

    @Override
    protected void updateMessage() {
        this.setMessage(Text.translatable("vcreactions.config.volume", (int)(this.value * 100)));
    }

    @Override
    protected void applyValue() {
        VCReactionsClient.config.volume = (int)(this.value * 100);
        VCReactionsClient.saveConfig();
    }
}

package com.vcreactions;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class SoundSynthesizer {
    private static final int SAMPLE_RATE = 48000;
    private static final Map<SoundType, short[]> sounds = new HashMap<>();

    static {
        // Синтезируем звуки по умолчанию
        sounds.put(SoundType.HIT, synthesizeHit());
        sounds.put(SoundType.COMBO, synthesizeCombo());
        sounds.put(SoundType.FALL, synthesizeFall());
        sounds.put(SoundType.ENVIRONMENT, synthesizeEnvironment());
        sounds.put(SoundType.DEATH, synthesizeDeath());
    }

    public static void loadCustomSounds(Path soundsDir) {
        for (SoundType type : SoundType.values()) {
            Path wavFile = soundsDir.resolve(type.name + ".wav");
            if (Files.exists(wavFile)) {
                try {
                    short[] samples = loadWav(wavFile);
                    if (samples != null) {
                        sounds.put(type, samples);
                        System.out.println("Loaded custom sound: " + type.name);
                    }
                } catch (Exception e) {
                    System.err.println("Failed to load " + wavFile + ": " + e.getMessage());
                }
            }
        }
    }

    private static short[] loadWav(Path path) throws Exception {
        AudioInputStream ais = AudioSystem.getAudioInputStream(path.toFile());
        AudioFormat format = ais.getFormat();

        // Конвертируем в 48kHz mono 16-bit если нужно
        if (format.getSampleRate() != SAMPLE_RATE || format.getChannels() != 1) {
            AudioFormat targetFormat = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                SAMPLE_RATE,
                16,
                1,
                2,
                SAMPLE_RATE,
                false
            );
            ais = AudioSystem.getAudioInputStream(targetFormat, ais);
        }

        byte[] bytes = ais.readAllBytes();
        short[] samples = new short[bytes.length / 2];
        for (int i = 0; i < samples.length; i++) {
            samples[i] = (short) ((bytes[i * 2 + 1] << 8) | (bytes[i * 2] & 0xFF));
        }
        return samples;
    }

    public static short[] getSamples(SoundType type) {
        return sounds.get(type);
    }

    private static short[] synthesizeHit() {
        int length = SAMPLE_RATE / 10; // 0.1s
        short[] samples = new short[length];
        for (int i = 0; i < length; i++) {
            double t = (double) i / SAMPLE_RATE;
            double envelope = Math.exp(-t * 15);
            double wave = Math.sin(2 * Math.PI * 400 * t);
            samples[i] = (short) (wave * envelope * 8000);
        }
        return samples;
    }

    private static short[] synthesizeCombo() {
        int length = SAMPLE_RATE / 2; // 0.5s
        short[] samples = new short[length];
        for (int i = 0; i < length; i++) {
            double t = (double) i / SAMPLE_RATE;
            double envelope = Math.exp(-t * 8);
            double wave = Math.sin(2 * Math.PI * 600 * t + Math.sin(2 * Math.PI * 50 * t) * 2);
            samples[i] = (short) (wave * envelope * 10000);
        }
        return samples;
    }

    private static short[] synthesizeFall() {
        int length = SAMPLE_RATE / 2; // 0.5s
        short[] samples = new short[length];
        for (int i = 0; i < length; i++) {
            double t = (double) i / SAMPLE_RATE;
            double freq = 800 - t * 600;
            double envelope = Math.exp(-t * 6);
            double wave = Math.sin(2 * Math.PI * freq * t);
            samples[i] = (short) (wave * envelope * 9000);
        }
        return samples;
    }

    private static short[] synthesizeEnvironment() {
        int length = SAMPLE_RATE / 3; // 0.33s
        short[] samples = new short[length];
        for (int i = 0; i < length; i++) {
            double t = (double) i / SAMPLE_RATE;
            double envelope = 1.0 - t * 3;
            double wave = Math.sin(2 * Math.PI * 200 * t) * 0.5 + Math.sin(2 * Math.PI * 300 * t) * 0.5;
            samples[i] = (short) (wave * envelope * 7000);
        }
        return samples;
    }

    private static short[] synthesizeDeath() {
        int length = SAMPLE_RATE; // 1s
        short[] samples = new short[length];
        for (int i = 0; i < length; i++) {
            double t = (double) i / SAMPLE_RATE;
            double freq = 500 - t * 400;
            double envelope = Math.exp(-t * 2);
            double wave = Math.sin(2 * Math.PI * freq * t);
            samples[i] = (short) (wave * envelope * 12000);
        }
        return samples;
    }
}

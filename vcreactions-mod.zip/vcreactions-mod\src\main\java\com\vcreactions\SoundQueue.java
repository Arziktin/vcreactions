package com.vcreactions;

import java.util.concurrent.ConcurrentLinkedQueue;

public class SoundQueue {
    private static final ConcurrentLinkedQueue<ActiveSound> activeSounds = new ConcurrentLinkedQueue<>();

    public static void playSound(SoundType type) {
        short[] samples = SoundSynthesizer.getSamples(type);
        if (samples != null) {
            activeSounds.add(new ActiveSound(samples));
        }
    }

    public static short[] mixAndGet() {
        if (activeSounds.isEmpty()) return null;

        short[] output = new short[960]; // 20ms at 48kHz mono
        float volume = VCReactionsClient.config.volume / 100.0f;

        activeSounds.removeIf(sound -> {
            int remaining = sound.samples.length - sound.position;
            int toCopy = Math.min(remaining, output.length);

            for (int i = 0; i < toCopy; i++) {
                float mixed = output[i] + sound.samples[sound.position + i] * volume;
                output[i] = (short) Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, mixed));
            }

            sound.position += toCopy;
            return sound.position >= sound.samples.length;
        });

        return output;
    }

    private static class ActiveSound {
        final short[] samples;
        int position = 0;

        ActiveSound(short[] samples) {
            this.samples = samples;
        }
    }
}

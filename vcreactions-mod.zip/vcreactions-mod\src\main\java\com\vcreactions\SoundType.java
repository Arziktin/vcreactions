package com.vcreactions;

public enum SoundType {
    HIT("hit"),
    COMBO("combo"),
    FALL("fall"),
    ENVIRONMENT("environment"),
    DEATH("death");

    public final String name;

    SoundType(String name) {
        this.name = name;
    }
}

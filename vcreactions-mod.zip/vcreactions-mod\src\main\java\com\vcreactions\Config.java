package com.vcreactions;

public class Config {
    public boolean enabled = true;
    public int volume = 70;
    public boolean hitEnabled = true;
    public boolean comboEnabled = true;
    public boolean fallEnabled = true;
    public boolean environmentEnabled = true;
    public boolean deathEnabled = true;

    public transient int comboHits = 3;
    public transient double comboTime = 2.5;
}

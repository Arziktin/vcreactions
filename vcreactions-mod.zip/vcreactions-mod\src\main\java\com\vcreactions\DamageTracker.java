package com.vcreactions;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.List;

public class DamageTracker {
    private static float lastHealth = 20.0f;
    private static float lastFallDistance = 0.0f;
    private static boolean wasOnGround = true;
    private static final List<Long> hitTimes = new ArrayList<>();
    private static boolean wasInDanger = false;

    public static void register() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick(client));
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || !VCReactionsClient.config.enabled) return;

        PlayerEntity player = client.player;
        float currentHealth = player.getHealth();
        boolean onGround = player.isOnGround();
        float fallDistance = player.fallDistance;

        // Смерть
        if (VCReactionsClient.config.deathEnabled && player.isDead() && lastHealth > 0) {
            SoundQueue.playSound(SoundType.DEATH);
        }

        // Урон от окружения
        boolean inDanger = player.isOnFire() || player.isInLava() ||
                          player.getAir() < player.getMaxAir() - 20 ||
                          player.getFrozenTicks() > player.getMinFreezeDamageTicks();

        if (VCReactionsClient.config.environmentEnabled && inDanger && !wasInDanger && currentHealth < lastHealth) {
            SoundQueue.playSound(SoundType.ENVIRONMENT);
        }
        wasInDanger = inDanger;

        // Урон от падения
        if (VCReactionsClient.config.fallEnabled && onGround && !wasOnGround && lastFallDistance > 3.0f && currentHealth < lastHealth) {
            SoundQueue.playSound(SoundType.FALL);
        }

        // Обычный удар и комбо
        if (currentHealth < lastHealth && currentHealth > 0) {
            long now = System.currentTimeMillis();
            hitTimes.add(now);
            hitTimes.removeIf(t -> now - t > VCReactionsClient.config.comboTime * 1000);

            if (VCReactionsClient.config.comboEnabled && hitTimes.size() >= VCReactionsClient.config.comboHits) {
                SoundQueue.playSound(SoundType.COMBO);
                hitTimes.clear();
            } else if (VCReactionsClient.config.hitEnabled && !inDanger && (wasOnGround || onGround)) {
                SoundQueue.playSound(SoundType.HIT);
            }
        }

        lastHealth = currentHealth;
        lastFallDistance = fallDistance;
        wasOnGround = onGround;
    }
}

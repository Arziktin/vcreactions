package com.vcreactions;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.gui.widget.button.AbstractButton;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class ConfigScreen extends Screen {
    private final Screen parent;
    private VolumeSlider volumeSlider;

    public ConfigScreen(Screen parent) {
        super(Text.translatable("vcreactions.config.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int x = this.width / 2 - 100;
        int y = 20;

        // Главный переключатель
        this.addDrawableChild(Button.builder(
            Text.translatable("vcreactions.config.enabled").append(": " + (VCReactionsClient.config.enabled ? "✓" : "✗")),
            btn -> {
                VCReactionsClient.config.enabled = !VCReactionsClient.config.enabled;
                btn.setMessage(Text.translatable("vcreactions.config.enabled").append(": " + (VCReactionsClient.config.enabled ? "✓" : "✗")));
                VCReactionsClient.saveConfig();
            }
        ).dimensions(x, y, 200, 20).build());
        y += 25;

        // Ползунок громкости
        volumeSlider = new VolumeSlider(x, y, 200, 20);
        this.addDrawableChild(volumeSlider);
        y += 30;

        // Переключатели реакций с кнопками тестов
        y = addReactionToggle(x, y, "hit", () -> VCReactionsClient.config.hitEnabled, v -> VCReactionsClient.config.hitEnabled = v, SoundType.HIT);
        y = addReactionToggle(x, y, "combo", () -> VCReactionsClient.config.comboEnabled, v -> VCReactionsClient.config.comboEnabled = v, SoundType.COMBO);
        y = addReactionToggle(x, y, "fall", () -> VCReactionsClient.config.fallEnabled, v -> VCReactionsClient.config.fallEnabled = v, SoundType.FALL);
        y = addReactionToggle(x, y, "environment", () -> VCReactionsClient.config.environmentEnabled, v -> VCReactionsClient.config.environmentEnabled = v, SoundType.ENVIRONMENT);
        addReactionToggle(x, y, "death", () -> VCReactionsClient.config.deathEnabled, v -> VCReactionsClient.config.deathEnabled = v, SoundType.DEATH);

        // Кнопка закрытия
        this.addDrawableChild(Button.builder(
            Text.literal("Готово"),
            btn -> this.close()
        ).dimensions(this.width / 2 - 50, this.height - 30, 100, 20).build());
    }

    private int addReactionToggle(int x, int y, String key, BooleanGetter getter, BooleanSetter setter, SoundType testSound) {
        this.addDrawableChild(Button.builder(
            Text.translatable("vcreactions.config." + key + ".enabled").append(": " + (getter.get() ? "✓" : "✗")),
            btn -> {
                setter.set(!getter.get());
                btn.setMessage(Text.translatable("vcreactions.config." + key + ".enabled").append(": " + (getter.get() ? "✓" : "✗")));
                VCReactionsClient.saveConfig();
            }
        ).dimensions(x, y, 130, 20).build());

        this.addDrawableChild(Button.builder(
            Text.translatable("vcreactions.config." + key + ".test"),
            btn -> SoundQueue.playSound(testSound)
        ).dimensions(x + 135, y, 65, 20).build());

        return y + 25;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 5, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }

    @FunctionalInterface
    interface BooleanGetter {
        boolean get();
    }

    @FunctionalInterface
    interface BooleanSetter {
        void set(boolean value);
    }
}

package com.vcreactions;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class VCReactionsClient implements ClientModInitializer {
    public static final String MOD_ID = "vcreactions";
    public static Config config = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = Path.of("config", "vcreactions.json");
    private static final Path SOUNDS_DIR = Path.of("config", "vcreactions");

    private static KeyBinding openConfigKey;

    @Override
    public void onInitializeClient() {
        loadConfig();
        loadSounds();

        KeyBinding.Category category = KeyBinding.Category.register(
            Identifier.of(MOD_ID, "main")
        );

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.vcreactions.open_config",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_K,
            category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openConfigKey.wasPressed()) {
                client.setScreen(new ConfigScreen(client.currentScreen));
            }
        });

        DamageTracker.register();
    }

    public static void loadConfig() {
        try {
            if (Files.exists(CONFIG_PATH)) {
                String json = Files.readString(CONFIG_PATH);
                config = GSON.fromJson(json, Config.class);
            } else {
                saveConfig();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveConfig() {
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            Files.writeString(CONFIG_PATH, GSON.toJson(config));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadSounds() {
        try {
            Files.createDirectories(SOUNDS_DIR);
            SoundSynthesizer.loadCustomSounds(SOUNDS_DIR);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package com.vcreactions;

import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MergeClientSoundEvent;

public class VoiceChatPlugin implements VoicechatPlugin {

    @Override
    public String getPluginId() {
        return VCReactionsClient.MOD_ID;
    }

    @Override
    public void initialize(VoicechatApi api) {
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MergeClientSoundEvent.class, this::onMergeSound);
    }

    private void onMergeSound(MergeClientSoundEvent event) {
        if (!VCReactionsClient.config.enabled) return;

        short[] reactionAudio = SoundQueue.mixAndGet();
        if (reactionAudio != null) {
            event.mergeAudio(reactionAudio);
        }
    }
}
